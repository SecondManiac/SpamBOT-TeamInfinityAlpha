# SPAMBOTS
[Gernate bot session from here](https://replit.com/@jattpawan/UstadOp#main.py)
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/dangerousjatt/SPAMBOTS)

This is modified version of Yukki Spammer
